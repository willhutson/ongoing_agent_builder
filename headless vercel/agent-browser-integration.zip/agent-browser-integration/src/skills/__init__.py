"""
Agent Skills Module

Shared capabilities that agents can invoke.
"""

from .agent_browser import AgentBrowserSkill, BrowserResult, SnapshotResult, quick_scrape

__all__ = [
    "AgentBrowserSkill",
    "BrowserResult", 
    "SnapshotResult",
    "quick_scrape",
]
